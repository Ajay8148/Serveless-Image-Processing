import boto3
from PIL import Image
import io
import os

s3 = boto3.client('s3')
PROCESSED_BUCKET = os.environ.get('PROCESSED_BUCKET', 'my-image-processed')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        response = s3.get_object(Bucket=bucket, Key=key)
        image_data = response['Body'].read()
        
        image = Image.open(io.BytesIO(image_data))
        image = image.resize((800, 800))  # Resize
        buffer = io.BytesIO()
        image.save(buffer, 'JPEG', quality=80)  # Compress
        buffer.seek(0)
        
        s3.put_object(Bucket=PROCESSED_BUCKET, Key=key, Body=buffer)
        print(f"Processed image {key} saved to {PROCESSED_BUCKET}")

